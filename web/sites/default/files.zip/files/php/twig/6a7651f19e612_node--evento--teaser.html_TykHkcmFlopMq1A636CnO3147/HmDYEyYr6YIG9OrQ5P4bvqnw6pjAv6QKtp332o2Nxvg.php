<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/unl_theme/templates/node/node--evento--teaser.html.twig */
class __TwigTemplate_0dc4111a784b46d153a3ce3e04e9077e extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<article class=\"evento-teaser\">

  <div class=\"evento-teaser__imagen\">

    ";
        // line 5
        if ((($tmp = Twig\Extension\CoreExtension::trim($this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "field_imagen", [], "any", false, false, true, 5)))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 6
            yield "      ";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "field_imagen", [], "any", false, false, true, 6), "html", null, true);
            yield "
    ";
        }
        // line 8
        yield "
    ";
        // line 9
        if ((($tmp = Twig\Extension\CoreExtension::trim($this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "field_fecha", [], "any", false, false, true, 9)))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 10
            yield "      <div class=\"evento-teaser__fecha\">
        <span class=\"evento-teaser__dia\">
            ";
            // line 12
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Twig\Extension\CoreExtension']->formatDate(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["node"] ?? null), "field_fecha", [], "any", false, false, true, 12), "value", [], "any", false, false, true, 12), "d"), "html", null, true);
            yield "
        </span>
        <span class=\"evento-teaser__mes\">
            ";
            // line 15
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Twig\Extension\CoreExtension']->formatDate(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["node"] ?? null), "field_fecha", [], "any", false, false, true, 15), "value", [], "any", false, false, true, 15), "M"), "html", null, true);
            yield "
        </span>
      </div>
    ";
        }
        // line 19
        yield "
  </div>

  <div class=\"evento-teaser__contenido\">

    <h3 class=\"evento-teaser__titulo\">
      ";
        // line 25
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["label"] ?? null), "html", null, true);
        yield "
    </h3>

    <div class=\"evento-teaser__divider\"></div>

    <div class=\"evento-teaser__meta\">

      ";
        // line 32
        if ((($tmp = Twig\Extension\CoreExtension::trim($this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "field_ubicacion", [], "any", false, false, true, 32)))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 33
            yield "        <div class=\"evento-teaser__meta-item evento-teaser__meta-item--ubicacion\">
          ";
            // line 34
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "field_ubicacion", [], "any", false, false, true, 34), "html", null, true);
            yield "
        </div>
      ";
        }
        // line 37
        yield "
      ";
        // line 38
        if ((($tmp = Twig\Extension\CoreExtension::trim($this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "field_area", [], "any", false, false, true, 38)))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 39
            yield "        <div class=\"evento-teaser__meta-item evento-teaser__meta-item--area\">
          ";
            // line 40
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "field_area", [], "any", false, false, true, 40), "html", null, true);
            yield "
        </div>
      ";
        }
        // line 43
        yield "
      ";
        // line 44
        if ((($tmp = Twig\Extension\CoreExtension::trim($this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "field_fecha", [], "any", false, false, true, 44)))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 45
            yield "        <div class=\"evento-teaser__meta-item evento-teaser__meta-item--hora\">
          ";
            // line 46
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Twig\Extension\CoreExtension']->formatDate(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "field_fecha", [], "any", false, false, true, 46), "value", [], "any", false, false, true, 46), "H:i"), "html", null, true);
            yield "
        </div>
      ";
        }
        // line 49
        yield "
    </div>

    ";
        // line 52
        if ((($tmp = Twig\Extension\CoreExtension::trim($this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "body", [], "any", false, false, true, 52)))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 53
            yield "      <div class=\"evento-teaser__cuerpo\">
        ";
            // line 54
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "body", [], "any", false, false, true, 54), "html", null, true);
            yield "
      </div>
    ";
        }
        // line 57
        yield "
  </div>

</article>";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["content", "node", "label"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/unl_theme/templates/node/node--evento--teaser.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  153 => 57,  147 => 54,  144 => 53,  142 => 52,  137 => 49,  131 => 46,  128 => 45,  126 => 44,  123 => 43,  117 => 40,  114 => 39,  112 => 38,  109 => 37,  103 => 34,  100 => 33,  98 => 32,  88 => 25,  80 => 19,  73 => 15,  67 => 12,  63 => 10,  61 => 9,  58 => 8,  52 => 6,  50 => 5,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "themes/custom/unl_theme/templates/node/node--evento--teaser.html.twig", "/opt/drupal/web/themes/custom/unl_theme/templates/node/node--evento--teaser.html.twig");
    }
    
    public function ensureSecurityChecked(): void
    {
        if ($this->sandbox->isSandboxed($this->source)) {
            $this->checkSecurity();
        }
    }
    
    public function checkSecurity()
    {
        static $tags = ["if" => 5];
        static $filters = ["trim" => 5, "render" => 5, "escape" => 6, "date" => 12];
        static $functions = [];
        static $tests = [];

        try {
            $this->sandbox->checkSecurity(
                [0 => "if"],
                [0 => "trim", 1 => "render", 2 => "escape", 3 => "date"],
                [],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            } elseif ($e instanceof SecurityNotAllowedTestError && isset($tests[$e->getTestName()])) {
                $e->setTemplateLine($tests[$e->getTestName()]);
            }

            throw $e;
        }

    }
}
