<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/unl_theme/templates/paragraphs/paragraph--hero-carrusel.html.twig */
class __TwigTemplate_c4d923554f365aba9c091dcf65976838 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'paragraph' => [$this, 'block_paragraph'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield from $this->unwrap()->yieldBlock('paragraph', $context, $blocks);
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["content"]);        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_paragraph(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        yield "  ";
        $context["slides_data"] = [];
        // line 3
        yield "
  ";
        // line 4
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "field_diapositivas", [], "any", false, false, true, 4));
        foreach ($context['_seq'] as $context["key"] => $context["child"]) {
            // line 5
            yield "    ";
            if ((Twig\Extension\CoreExtension::first($this->env->getCharset(), $context["key"]) != "#")) {
                // line 6
                yield "      
      ";
                // line 7
                $context["url_imagen"] = "";
                // line 8
                yield "      ";
                if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (($_v0 = $context["child"]) && is_array($_v0) || $_v0 instanceof ArrayAccess && in_array($_v0::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v0["#paragraph"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, $context["child"], "#paragraph", [], "array", false, false, true, 8)), "field_imagen", [], "any", false, false, true, 8), "entity", [], "any", false, false, true, 8)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 9
                    yield "        ";
                    $context["url_imagen"] = $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (($_v1 = $context["child"]) && is_array($_v1) || $_v1 instanceof ArrayAccess && in_array($_v1::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v1["#paragraph"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, $context["child"], "#paragraph", [], "array", false, false, true, 9)), "field_imagen", [], "any", false, false, true, 9), "entity", [], "any", false, false, true, 9), "field_media_image", [], "any", false, false, true, 9), "entity", [], "any", false, false, true, 9), "uri", [], "any", false, false, true, 9), "value", [], "any", false, false, true, 9));
                    // line 10
                    yield "      ";
                }
                // line 11
                yield "
      ";
                // line 12
                $context["slides_data"] = Twig\Extension\CoreExtension::merge(($context["slides_data"] ?? null), [["titulo" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (($_v2 =                 // line 13
$context["child"]) && is_array($_v2) || $_v2 instanceof ArrayAccess && in_array($_v2::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v2["#paragraph"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, $context["child"], "#paragraph", [], "array", false, false, true, 13)), "field_titulo", [], "any", false, false, true, 13), "value", [], "any", false, false, true, 13), "descripcion" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (($_v3 =                 // line 14
$context["child"]) && is_array($_v3) || $_v3 instanceof ArrayAccess && in_array($_v3::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v3["#paragraph"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, $context["child"], "#paragraph", [], "array", false, false, true, 14)), "field_descripcion", [], "any", false, false, true, 14), "value", [], "any", false, false, true, 14), "imagen_url" =>                 // line 15
($context["url_imagen"] ?? null), "enlace_url" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (($_v4 =                 // line 16
$context["child"]) && is_array($_v4) || $_v4 instanceof ArrayAccess && in_array($_v4::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v4["#paragraph"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, $context["child"], "#paragraph", [], "array", false, false, true, 16)), "field_enlace", [], "any", false, false, true, 16), "uri", [], "any", false, false, true, 16), "enlace_texto" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (($_v5 =                 // line 17
$context["child"]) && is_array($_v5) || $_v5 instanceof ArrayAccess && in_array($_v5::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v5["#paragraph"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, $context["child"], "#paragraph", [], "array", false, false, true, 17)), "field_enlace", [], "any", false, false, true, 17), "title", [], "any", false, false, true, 17)]]);
                // line 19
                yield "
    ";
            }
            // line 21
            yield "  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['key'], $context['child'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 22
        yield "
  ";
        // line 23
        yield from $this->load("unl_theme:hero_carrusel", 23)->unwrap()->yield(CoreExtension::merge($context, ["diapositivas" =>         // line 24
($context["slides_data"] ?? null)]));
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/unl_theme/templates/paragraphs/paragraph--hero-carrusel.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  109 => 24,  108 => 23,  105 => 22,  98 => 21,  94 => 19,  92 => 17,  91 => 16,  90 => 15,  89 => 14,  88 => 13,  87 => 12,  84 => 11,  81 => 10,  78 => 9,  75 => 8,  73 => 7,  70 => 6,  67 => 5,  63 => 4,  60 => 3,  57 => 2,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "themes/custom/unl_theme/templates/paragraphs/paragraph--hero-carrusel.html.twig", "/opt/drupal/web/themes/custom/unl_theme/templates/paragraphs/paragraph--hero-carrusel.html.twig");
    }
    
    public function ensureSecurityChecked(): void
    {
        if ($this->sandbox->isSandboxed($this->source)) {
            $this->checkSecurity();
        }
    }
    
    public function checkSecurity()
    {
        static $tags = ["block" => 1, "set" => 2, "for" => 4, "if" => 5, "include" => 23];
        static $filters = ["first" => 5, "merge" => 12];
        static $functions = ["file_url" => 9];
        static $tests = [];

        try {
            $this->sandbox->checkSecurity(
                [0 => "block", 1 => "set", 2 => "for", 3 => "if", 4 => "include"],
                [0 => "first", 1 => "merge"],
                [0 => "file_url"],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            } elseif ($e instanceof SecurityNotAllowedTestError && isset($tests[$e->getTestName()])) {
                $e->setTemplateLine($tests[$e->getTestName()]);
            }

            throw $e;
        }

    }
}
