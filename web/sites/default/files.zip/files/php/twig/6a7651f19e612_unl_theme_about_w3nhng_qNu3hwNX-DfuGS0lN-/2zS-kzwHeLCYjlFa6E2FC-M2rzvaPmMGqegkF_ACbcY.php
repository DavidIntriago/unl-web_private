<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* unl_theme:about */
class __TwigTemplate_2304db52f49216522e45304e07b939b5 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("core/components.unl_theme--about"));
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->addAdditionalContext($context, "unl_theme:about"));
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->validateProps($context, "unl_theme:about"));
        yield "<section class=\"unl-about\">
  <div class=\"unl-about__container\">
    
    <div class=\"unl-about__content\">
      
      ";
        // line 6
        if (((($tmp = ($context["titulo"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($tmp = ($context["titulo_2"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 7
            yield "        <h2 class=\"unl-about__title\">
          ";
            // line 8
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["titulo"] ?? null), "html", null, true);
            yield "
          ";
            // line 9
            if ((($tmp = ($context["titulo_2"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 10
                yield "            <span class=\"unl-about__highlight\">";
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["titulo_2"] ?? null), "html", null, true);
                yield "</span>
          ";
            }
            // line 12
            yield "        </h2>
        
        ";
            // line 14
            $context["is_default"] = ( !(($tmp = ($context["color"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($context["color"] ?? null) == "bg-gray-100"));
            // line 15
            yield "        <div class=\"unl-about__divider ";
            yield (string) (((($tmp = ($context["is_default"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("unl-about__divider--multicolor") : ($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["color"] ?? null), "html", null, true)));
            yield "\"></div>
        
      ";
        }
        // line 18
        yield "      
      ";
        // line 19
        if ((($tmp = ($context["descripcion"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 20
            yield "        <div class=\"unl-about__description\">
          ";
            // line 21
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["descripcion"] ?? null), "html", null, true);
            yield "
        </div>
      ";
        }
        // line 24
        yield "      
      ";
        // line 25
        if ((($tmp = ($context["enlace"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 26
            yield "        <div class=\"unl-about__action\">
          ";
            // line 27
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["enlace"] ?? null), "html", null, true);
            yield "
        </div>
      ";
        }
        // line 30
        yield "    </div>

    ";
        // line 32
        if ((($tmp = ($context["media"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 33
            yield "      <div class=\"unl-about__media\">
        ";
            // line 34
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["media"] ?? null), "html", null, true);
            yield "
      </div>
    ";
        }
        // line 37
        yield "
  </div>
</section>";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["titulo", "titulo_2", "color", "descripcion", "enlace", "media"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "unl_theme:about";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  127 => 37,  121 => 34,  118 => 33,  116 => 32,  112 => 30,  106 => 27,  103 => 26,  101 => 25,  98 => 24,  92 => 21,  89 => 20,  87 => 19,  84 => 18,  77 => 15,  75 => 14,  71 => 12,  65 => 10,  63 => 9,  59 => 8,  56 => 7,  54 => 6,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "unl_theme:about", "themes/custom/unl_theme/components/about /about.twig");
    }
    
    public function ensureSecurityChecked(): void
    {
        if ($this->sandbox->isSandboxed($this->source)) {
            $this->checkSecurity();
        }
    }
    
    public function checkSecurity()
    {
        static $tags = ["if" => 6, "set" => 14];
        static $filters = ["escape" => 8];
        static $functions = [];
        static $tests = [];

        try {
            $this->sandbox->checkSecurity(
                [0 => "if", 1 => "set"],
                [0 => "escape"],
                [],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            } elseif ($e instanceof SecurityNotAllowedTestError && isset($tests[$e->getTestName()])) {
                $e->setTemplateLine($tests[$e->getTestName()]);
            }

            throw $e;
        }

    }
}
