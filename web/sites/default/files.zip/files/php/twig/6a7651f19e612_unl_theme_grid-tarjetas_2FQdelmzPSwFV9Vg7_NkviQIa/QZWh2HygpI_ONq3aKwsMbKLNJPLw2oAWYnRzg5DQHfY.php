<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* unl_theme:grid-tarjetas */
class __TwigTemplate_335332a71e10af189870c1ca9e8ad178 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'items' => [$this, 'block_items'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("core/components.unl_theme--grid-tarjetas"));
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->addAdditionalContext($context, "unl_theme:grid-tarjetas"));
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->validateProps($context, "unl_theme:grid-tarjetas"));
        $context["modificador_wrapper"] = (((($tmp = ($context["variante"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (("grid-tarjetas-wrapper--" . ($context["variante"] ?? null))) : (""));
        // line 2
        yield "
<div class=\"grid-tarjetas-wrapper ";
        // line 3
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["modificador_wrapper"] ?? null), "html", null, true);
        yield "\">

  ";
        // line 5
        if ((($tmp = ($context["titulo"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 6
            yield "    <div class=\"grid-tarjetas__header\">
      <h2 class=\"grid-tarjetas__titulo\">
        ";
            // line 8
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["titulo"] ?? null), "html", null, true);
            yield "
      </h2>
      <div class=\"grid-tarjetas__divider\"></div>
    </div>
  ";
        }
        // line 13
        yield "
  ";
        // line 14
        $context["modificador_grid"] = (((($context["variante"] ?? null) == "facultad")) ? ("grid-tarjetas-container--facultad") : ((((        // line 16
($context["variante"] ?? null) == "contador")) ? ("grid-tarjetas-container--contador") : ((((        // line 18
($context["variante"] ?? null) == "sitios_interes")) ? ("grid-tarjetas-container--sitios_interes") : ((((        // line 20
($context["variante"] ?? null) == "imagenes")) ? ("grid-tarjetas-container--imagenes") : ("grid-tarjetas-container--default"))))))));
        // line 23
        yield "
  <section class=\"grid-tarjetas-container ";
        // line 24
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["modificador_grid"] ?? null), "html", null, true);
        yield "\">
    ";
        // line 25
        if ((($context["variante"] ?? null) == "sitios_interes")) {
            // line 26
            yield "      <button class=\"carrusel-sitios-flecha prev\" aria-label=\"Anterior\">&#10094;</button>
      <div class=\"carrusel-sitios-viewport\">
        <div class=\"carrusel-sitios-track\">
    ";
        }
        // line 30
        yield "
    ";
        // line 31
        yield from $this->unwrap()->yieldBlock('items', $context, $blocks);
        // line 33
        yield "
    ";
        // line 34
        if ((($context["variante"] ?? null) == "sitios_interes")) {
            // line 35
            yield "        </div>
      </div>
      <button class=\"carrusel-sitios-flecha next\" aria-label=\"Siguiente\">&#10095;</button>
    ";
        }
        // line 39
        yield "  </section>

</div>";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["variante", "titulo"]);        yield from [];
    }

    // line 31
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_items(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 32
        yield "    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "unl_theme:grid-tarjetas";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  126 => 32,  119 => 31,  111 => 39,  105 => 35,  103 => 34,  100 => 33,  98 => 31,  95 => 30,  89 => 26,  87 => 25,  83 => 24,  80 => 23,  78 => 20,  77 => 18,  76 => 16,  75 => 14,  72 => 13,  64 => 8,  60 => 6,  58 => 5,  53 => 3,  50 => 2,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "unl_theme:grid-tarjetas", "themes/custom/unl_theme/components/grid_tarjetas/grid-tarjetas.twig");
    }
    
    public function ensureSecurityChecked(): void
    {
        if ($this->sandbox->isSandboxed($this->source)) {
            $this->checkSecurity();
        }
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 1, "if" => 5, "block" => 31];
        static $filters = ["escape" => 3];
        static $functions = [];
        static $tests = [];

        try {
            $this->sandbox->checkSecurity(
                [0 => "set", 1 => "if", 2 => "block"],
                [0 => "escape"],
                [],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            } elseif ($e instanceof SecurityNotAllowedTestError && isset($tests[$e->getTestName()])) {
                $e->setTemplateLine($tests[$e->getTestName()]);
            }

            throw $e;
        }

    }
}
