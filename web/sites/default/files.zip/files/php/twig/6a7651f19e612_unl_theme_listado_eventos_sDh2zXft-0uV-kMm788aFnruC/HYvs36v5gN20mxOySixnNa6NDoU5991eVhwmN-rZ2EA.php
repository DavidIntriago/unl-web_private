<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* unl_theme:listado_eventos_dinamico */
class __TwigTemplate_9aaa8406480d07497bdb6427c6aadc36 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'boton_enlace' => [$this, 'block_boton_enlace'],
            'vista_eventos' => [$this, 'block_vista_eventos'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("core/components.unl_theme--listado_eventos_dinamico"));
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->addAdditionalContext($context, "unl_theme:listado_eventos_dinamico"));
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->validateProps($context, "unl_theme:listado_eventos_dinamico"));
        yield "<section class=\"seccion-eventos\">
  <div class=\"seccion-eventos__contenedor\">
    
    <div class=\"seccion-eventos__cabecera\">
      
      <div class=\"seccion-eventos__titulos\">
        ";
        // line 7
        if ((($tmp = ($context["titulo"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 8
            yield "          <h2 class=\"seccion-eventos__titulo\">";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["titulo"] ?? null), "html", null, true);
            yield "</h2>
                <div class=\"seccion-eventos__divider\"></div>
        ";
        }
        // line 11
        yield "      </div>

      <div class=\"seccion-eventos__boton-superior\">
        ";
        // line 14
        yield from $this->unwrap()->yieldBlock('boton_enlace', $context, $blocks);
        // line 15
        yield "      </div>
      
    </div>
    
    <div class=\"seccion-eventos__contenido\">
      ";
        // line 20
        yield from $this->unwrap()->yieldBlock('vista_eventos', $context, $blocks);
        // line 21
        yield "    </div>

  </div>
</section>";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["titulo"]);        yield from [];
    }

    // line 14
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_boton_enlace(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 20
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_vista_eventos(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "unl_theme:listado_eventos_dinamico";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  101 => 20,  91 => 14,  82 => 21,  80 => 20,  73 => 15,  71 => 14,  66 => 11,  59 => 8,  57 => 7,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "unl_theme:listado_eventos_dinamico", "themes/custom/unl_theme/components/listado_eventos_dinamico/listado_eventos_dinamico.twig");
    }
    
    public function ensureSecurityChecked(): void
    {
        if ($this->sandbox->isSandboxed($this->source)) {
            $this->checkSecurity();
        }
    }
    
    public function checkSecurity()
    {
        static $tags = ["if" => 7, "block" => 14];
        static $filters = ["escape" => 8];
        static $functions = [];
        static $tests = [];

        try {
            $this->sandbox->checkSecurity(
                [0 => "if", 1 => "block"],
                [0 => "escape"],
                [],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            } elseif ($e instanceof SecurityNotAllowedTestError && isset($tests[$e->getTestName()])) {
                $e->setTemplateLine($tests[$e->getTestName()]);
            }

            throw $e;
        }

    }
}
