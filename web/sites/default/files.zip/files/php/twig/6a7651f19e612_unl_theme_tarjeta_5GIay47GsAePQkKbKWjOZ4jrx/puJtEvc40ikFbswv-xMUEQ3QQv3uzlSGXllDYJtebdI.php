<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* unl_theme:tarjeta */
class __TwigTemplate_ac51ec41df0e2ce500a70fbbbce96e06 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("core/components.unl_theme--tarjeta"));
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->addAdditionalContext($context, "unl_theme:tarjeta"));
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->validateProps($context, "unl_theme:tarjeta"));
        if ((($context["variante"] ?? null) == "facultad")) {
            // line 2
            yield "  ";
            // line 3
            yield "  ";
            $context["classes"] = ["tarjeta-institucional",             // line 5
($context["color"] ?? null)];
            // line 7
            yield "
<article class=\"";
            // line 8
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, Twig\Extension\CoreExtension::join(($context["classes"] ?? null), " "), "html", null, true);
            yield "\">
  
  ";
            // line 10
            if ((($tmp = ($context["imagen"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 11
                yield "    <div class=\"tarjeta-bg-img\">
      ";
                // line 12
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["imagen"] ?? null), "html", null, true);
                yield "
    </div>
  ";
            }
            // line 15
            yield "
  <div class=\"tarjeta-contenido\">
    <h3 class=\"tarjeta-titulo\">
      ";
            // line 18
            yield (string) Twig\Extension\CoreExtension::nl2br($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["titulo"] ?? null), "html", null, true));
            yield " 
    </h3>
  </div>

  ";
            // line 22
            if ((($tmp = ($context["enlace"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 23
                yield "    <div class=\"tarjeta-institucional__enlace\">
      ";
                // line 24
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["enlace"] ?? null), "html", null, true);
                yield "
    </div>
  ";
            }
            // line 27
            yield "  
</article>
";
        } elseif ((        // line 29
($context["variante"] ?? null) == "contador")) {
            // line 30
            yield "
  ";
            // line 32
            yield "
  <article class=\"tarjeta-contador\">

    ";
            // line 35
            if ((($tmp = ($context["imagen"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 36
                yield "      <div class=\"tarjeta-contador__icono\">
        ";
                // line 37
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["imagen"] ?? null), "html", null, true);
                yield "
      </div>
    ";
            }
            // line 40
            yield "
    ";
            // line 41
            if ((($tmp = ($context["titulo"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 42
                yield "      <div class=\"tarjeta-contador__numero\">";
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["titulo"] ?? null), "html", null, true);
                yield "</div>
    ";
            }
            // line 44
            yield "
    ";
            // line 45
            if ((($tmp = ($context["descripcion"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 46
                yield "      <div class=\"tarjeta-contador__etiqueta\">";
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["descripcion"] ?? null), "html", null, true);
                yield "</div>
    ";
            }
            // line 48
            yield "
  </article>
";
        } elseif ((        // line 50
($context["variante"] ?? null) == "sitios_interes")) {
            // line 51
            yield "
  ";
            // line 53
            yield "
  <article class=\"tarjeta-sitio-interes\">

    ";
            // line 56
            if ((($tmp = ($context["imagen"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 57
                yield "      <div class=\"tarjeta-sitio-interes__icono\">
        ";
                // line 58
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["imagen"] ?? null), "html", null, true);
                yield "
      </div>
    ";
            }
            // line 61
            yield "
    ";
            // line 62
            if ((($tmp = ($context["titulo"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 63
                yield "      <h3 class=\"tarjeta-sitio-interes__titulo\">";
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["titulo"] ?? null), "html", null, true);
                yield "</h3>
    ";
            }
            // line 65
            yield "
    ";
            // line 66
            if ((($tmp = ($context["enlace"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 67
                yield "      <div class=\"tarjeta-sitio-interes__enlace\">
        ";
                // line 68
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["enlace"] ?? null), "html", null, true);
                yield "
      </div>
    ";
            }
            // line 71
            yield "
  </article>
";
        } elseif ((        // line 73
($context["variante"] ?? null) == "imagenes")) {
            // line 74
            yield "
  ";
            // line 76
            yield "
  <article class=\"tarjeta-imagen\">

    ";
            // line 79
            if ((($tmp = ($context["imagen"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 80
                yield "      ";
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["imagen"] ?? null), "html", null, true);
                yield "
    ";
            }
            // line 82
            yield "
    ";
            // line 83
            if ((($tmp = ($context["enlace"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 84
                yield "      <div class=\"tarjeta-imagen__enlace\">
        ";
                // line 85
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["enlace"] ?? null), "html", null, true);
                yield "
      </div>
    ";
            }
            // line 88
            yield "
  </article>
";
        } else {
            // line 91
            yield "  
  ";
            // line 93
            yield "  
  ";
            // line 94
            $context["classes"] = ["tarjeta-default",             // line 96
($context["color"] ?? null)];
            // line 98
            yield "
  <article class=\"";
            // line 99
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, Twig\Extension\CoreExtension::join(($context["classes"] ?? null), " "), "html", null, true);
            yield "\">
    
    ";
            // line 101
            if ((($tmp = ($context["imagen"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 102
                yield "      <div class=\"tarjeta-default__imagen\">
        ";
                // line 103
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["imagen"] ?? null), "html", null, true);
                yield "
      </div>
    ";
            }
            // line 106
            yield "
    <div class=\"tarjeta-default__contenido\">
      
      ";
            // line 109
            if ((($tmp = ($context["titulo"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 110
                yield "        <h3 class=\"tarjeta-default__titulo\">";
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["titulo"] ?? null), "html", null, true);
                yield "</h3>
      ";
            }
            // line 112
            yield "
      ";
            // line 113
            if ((($tmp = ($context["descripcion"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 114
                yield "        <div class=\"tarjeta-default__descripcion\">
          ";
                // line 115
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["descripcion"] ?? null), "html", null, true);
                yield "
        </div>
      ";
            }
            // line 118
            yield "
      ";
            // line 119
            if ((($tmp = ($context["enlace"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 120
                yield "        <div class=\"tarjeta-default__enlace\">
          ";
                // line 121
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["enlace"] ?? null), "html", null, true);
                yield "
        </div>
      ";
            }
            // line 124
            yield "
    </div>
  </article>
";
        }
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["variante", "color", "imagen", "titulo", "enlace", "descripcion"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "unl_theme:tarjeta";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  304 => 124,  298 => 121,  295 => 120,  293 => 119,  290 => 118,  284 => 115,  281 => 114,  279 => 113,  276 => 112,  270 => 110,  268 => 109,  263 => 106,  257 => 103,  254 => 102,  252 => 101,  247 => 99,  244 => 98,  242 => 96,  241 => 94,  238 => 93,  235 => 91,  230 => 88,  224 => 85,  221 => 84,  219 => 83,  216 => 82,  210 => 80,  208 => 79,  203 => 76,  200 => 74,  198 => 73,  194 => 71,  188 => 68,  185 => 67,  183 => 66,  180 => 65,  174 => 63,  172 => 62,  169 => 61,  163 => 58,  160 => 57,  158 => 56,  153 => 53,  150 => 51,  148 => 50,  144 => 48,  138 => 46,  136 => 45,  133 => 44,  127 => 42,  125 => 41,  122 => 40,  116 => 37,  113 => 36,  111 => 35,  106 => 32,  103 => 30,  101 => 29,  97 => 27,  91 => 24,  88 => 23,  86 => 22,  79 => 18,  74 => 15,  68 => 12,  65 => 11,  63 => 10,  58 => 8,  55 => 7,  53 => 5,  51 => 3,  49 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "unl_theme:tarjeta", "themes/custom/unl_theme/components/tarjeta/tarjeta.twig");
    }
    
    public function ensureSecurityChecked(): void
    {
        if ($this->sandbox->isSandboxed($this->source)) {
            $this->checkSecurity();
        }
    }
    
    public function checkSecurity()
    {
        static $tags = ["if" => 1, "set" => 3];
        static $filters = ["escape" => 8, "join" => 8, "nl2br" => 18];
        static $functions = [];
        static $tests = [];

        try {
            $this->sandbox->checkSecurity(
                [0 => "if", 1 => "set"],
                [0 => "escape", 1 => "join", 2 => "nl2br"],
                [],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            } elseif ($e instanceof SecurityNotAllowedTestError && isset($tests[$e->getTestName()])) {
                $e->setTemplateLine($tests[$e->getTestName()]);
            }

            throw $e;
        }

    }
}
